import express from "express";
import loginController from "../controllers/loginController";
import postController from "../controllers/postController";
import signupController from "../controllers/signupController";
import { upload } from "../multer/multerFun";

const router = express.Router();

router.post("/postcreate", upload.single("image"), postController().postcreate);
router.post("/singup", signupController().signup);
router.post("/login", loginController().login);
router.get("/getpost", postController().getPost);
router.get("/:_id", postController().postById);


export default router;
