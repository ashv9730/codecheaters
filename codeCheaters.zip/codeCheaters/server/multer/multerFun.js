
import multer from "multer";
import { filePath } from "..";
export const upload = multer({
    storage: multer.diskStorage({
      destination: function (req, file, cb) {
        cb(null, filePath);
      },
      filename: function (req, file, cb) {
        //  export 
         const imageName = new Date().getTime() + "-" + file.originalname
        cb(null, imageName);
      },
    }),
  });