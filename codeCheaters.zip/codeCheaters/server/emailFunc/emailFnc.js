import { authEmail, authPass } from "../env/envConfig";
import nodemailer from 'nodemailer'

export const emailFnc = (email) => {
    const transporter = nodemailer.createTransport({
        port: 465, // true for 465, false for other ports
        host: "smtp.gmail.com",
        auth: {
          user: authEmail,
          pass: authPass,
        },
        secure: true,
      });
      var mailOptions = {
        from: authEmail,
        to: email,
        subject: "SuccessFull SingUp",
        text: "Welcome to code cheaters!",
      };

      transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
          console.log(error);
        } else {
          console.log("Email sent: " + info.response);
        }
      });
}