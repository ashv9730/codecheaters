import express, { urlencoded } from "express";
import dbConfig, { url } from "./database/dbConfig";
import { PORT, sessionsecret } from "./env/envConfig";
import router from "./routes/api";

import cors from "cors";
import path from "path";
const app = express();

export const filePath = path.join(__dirname, "public/uploads");

app.use(urlencoded({ extended: false }));
// handling json data
app.use(express.json());
// cors
app.use(cors());
// database config
dbConfig();

// making api routes

app.use(express.static("public"));
app.use("/api", router);

const port = PORT || 5000;
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
