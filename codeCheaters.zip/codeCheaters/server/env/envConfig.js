import * as dotenv from 'dotenv'
dotenv.config() 

export const {dbUser,dbPassword,dbName,PORT,authEmail ,authPass,sessionsecret} = process.env