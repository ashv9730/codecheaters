import Post from "../models/Post";
export default function postController() {
  return {
    postcreate(req, res) {
      try {
        const { title, description } = req.body;

        if (!req.file) {
          return res.send({ message: "Image Required" });
        }
        const imageName = `http://localhost:3100/uploads/${req.file.filename}`;
        if (!title || !description || !imageName) {
          return res.send({ message: "You Missed Something" });
        }
        // const url = `post/${_id}`
        const post = new Post({
          title,
          description,
          image: imageName,
        });

        post
          .save()
          .then(() => {
            return res.send({ message: "Post Save SuccesFully" });
          })
          .catch((err) => {
            return res.send({ message: err.message });
          });
      } catch (error) {
        return res.send({ message: error.message });
      }
    },
    getPost(req, res) {
      try {
        Post.find()
          .then((post) => {
            return res.send(post);
          })
          .catch((err) => {
            return res.send({ message: err.message });
          });
      } catch (error) {
        return res.send({ message: error.message });
      }
    },
    postById(req,res){

      try {
        const {_id} = req.params
        Post.findById({_id})
        .then((post) => {
          return res.send(post);
        })
        .catch((err) => {
          return res.send({ message: err.message });
        });
      } catch (error) {
        return res.send({ message: error.message });
      }
    }
  };

}
