import Users from "../models/Users";
import bcrypt from "bcrypt";
import { emailFnc } from "../emailFunc/emailFnc";


export default function signupController() {
  return {
    async signup(req, res) {
      try {
        const { firstName, lastName, contact, email, password } = req.body;
        if (!firstName || !lastName || !contact || !email || !password) {
          return res.send({
            message: "All Fields are required! Plz try again",
          });
        }
        const emailReg = await Users.findOne({ email });
        if (emailReg) {
          return res.send({ message: "Email already Registered" });
        }

        const hashPassword = await bcrypt.hash(password, 10);
        const user = new Users({
          firstName,
          lastName,
          contact,
          email,
          password: hashPassword,
        });
        user
          .save()
          .then((result) => {
            emailFnc(email)
            return res.send({ message: "SignUp SucessFul" });
          })
          .catch((error) => {
            return res.send({ message: error.message });
          });
      } catch (error) {
        return res.send({ message: error.message });
      }
    },
  };
}
