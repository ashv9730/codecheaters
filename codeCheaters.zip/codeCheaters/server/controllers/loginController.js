import Users from "../models/Users";
import bcrypt from "bcrypt";
export default function loginController() {
  return {
    async login(req, res) {
      const { email, password } = req.body;
      const user = await Users.findOne({ email })
      
      const match = await bcrypt.compare(password, user.password);

      if (!match) {
       return res.send({message : "Email and Password Not Match"})
      }
      const newUser = await Users.findOne({ email }).select(['_id','firstName','lastName','email'])
      return res.send({
        newUser,
        token: "test123",
        message: "Login SuccessFul",
      });
      // return res.send({message : "All Okk"})
    },
  };
}

