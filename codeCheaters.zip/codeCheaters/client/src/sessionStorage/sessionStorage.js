export const getToken = () => {
    const tokenString = localStorage.getItem('token');
    const userToken = JSON.parse(tokenString);
    return userToken?.token
  }

export const setToken = (userToken) =>{
    localStorage.setItem('token', JSON.stringify(userToken));
  }

  export  const logout = () =>{
    localStorage.removeItem("token")
    window.location.reload()
  }

  
  export const Usertoken = getToken()