import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { getToken, logout, Usertoken } from "../sessionStorage/sessionStorage";

const Navbar = () => {

  
 
  return (
    <div>
      <nav class="flex mt-4 justify-between mx-4">
        <div class="ml-0">
          <Link
            to={"/"}
            class="font-bold px-3 py-2 text-slate-700 rounded-lg hover:bg-slate-100 hover:text-slate-900"
          >
            Home
          </Link>
          <Link
            to={"/team"}
            class="font-bold px-3 py-2 text-slate-700 rounded-lg hover:bg-slate-100 hover:text-slate-900"
          >
            Team
          </Link>
          <Link
            to={"/projects"}
            class="font-bold px-3 py-2 text-slate-700 rounded-lg hover:bg-slate-100 hover:text-slate-900"
          >
            Projects
          </Link>
          <Link
            to={"/reports"}
            class="font-bold px-3 py-2 text-slate-700 rounded-lg hover:bg-slate-100 hover:text-slate-900"
          >
            Reports
          </Link>
        </div>
        <div class="mr-40">
          <h3
            class="font-bold text-xl font-xl text-600
  "
          >
            Code Cheaters
          </h3>
        </div>
        <div class="mr-0">
          {
            Usertoken  ?
            <Link
              class="font-bold px-3 py-2 text-slate-700 rounded-lg hover:bg-slate-100 hover:text-slate-900"
              onClick={logout}
            >
              Logout
            </Link>
            :
            <>
            <Link
              to={"/login"}
              class="font-bold px-3 py-2 text-slate-700 rounded-lg hover:bg-slate-100 hover:text-slate-900"
            >
              Login
            </Link>
            <Link
              to={"/signup"}
              class="font-bold px-3 py-2 text-slate-700 rounded-lg hover:bg-slate-100 hover:text-slate-900"
            >
              SignUp
            </Link>
          </>
          }
          
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
