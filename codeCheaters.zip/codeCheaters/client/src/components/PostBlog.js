import React from "react";
import { postCreate } from "../axios/axiosRequest";
import notification from "../noty/noty";

const PostBlog = () => {
  const handlePost = async(e) => {
    e.preventDefault();
    const fileField = document.querySelector('input[type="file"]');
    const title = document.querySelector('#title')
    const description = document.querySelector('#description')
    const formData = new FormData()
    formData.append("title", title.value);
    formData.append("description", description.value);
    formData.append("image", fileField.files[0]);
    const res = await postCreate(formData);
    if (res.message === 'You Missed Something') {
      notification(res.message, 'error')
      return;
    }
    if (res.message === 'Image Required') {
      notification(res.message, 'error')
      return;
    }
    notification(res.message)

    setTimeout(() => {
      window.location.reload()
    }, 5000);
  };
  return (
    <div class='my-5 mx-10 '>
      <form onSubmit={handlePost} id='form'>
      <h3 class="font-bold text-xl mb-5"> Login Page</h3>
        <div class="form-group mb-6">
            <input
              type="text"
              name="title"
              class="form-control block
        w-full
        px-3
        py-1.5
        text-base
        font-normal
        text-gray-700
        bg-white bg-clip-padding
        border border-solid border-gray-300
        rounded
        transition
        ease-in-out
        m-0
        focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
              id="title"
              placeholder=" Blog Title"
            />
          </div>

          <div class="form-group mb-6">
            <textarea rows={5}
              
              name="description"
              class="form-control block
        w-full
        px-3
        py-1.5
        text-base
        font-normal
        text-gray-700
        bg-white bg-clip-padding
        border border-solid border-gray-300
        rounded
        transition
        ease-in-out
        m-0
        focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
              id="description"
              placeholder="Blog Description"
            />
          </div>

          <div class="form-group mb-6">
          <input type="file" name="image" />
          </div>

          
          <button
            type="submit"
            class="
      
      px-6
      py-2.5
      bg-blue-600
      text-white
      font-medium
      text-xs
      leading-tight
      uppercase
      rounded
      shadow-md
      hover:bg-blue-700 hover:shadow-lg
      focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0
      active:bg-blue-800 active:shadow-lg
      transition
      duration-150
      ease-in-out"
          >
            submit
          </button>
      </form>
    </div>
  );
};

export default PostBlog;
