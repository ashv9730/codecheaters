import React from 'react'


const Home = () => {
  
  return (
    <div>
        <main className="container">
        <h1 className="title">
          Welcome to <a href="">Code Cheaters</a>
        </h1>

        <p className="description">
          You didn’t just cheat in exam;
          <br /> you cheated on your future.
          <br />
          You didn’t just break my 💔heart💔;
          <br /> you broke your future.
        </p>

        <div className="grid">
          <a href="https://nextjs.org/docs" className="card">
            <h2>Documentation &rarr;</h2>
            <p>Find in-depth information about Next.js features and API.</p>
          </a>
        </div>
      </main>
    </div>
  )
}

export default Home