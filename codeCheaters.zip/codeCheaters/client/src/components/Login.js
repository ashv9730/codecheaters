import React from "react";
import { getLogin } from "../axios/axiosRequest";
import notification from "../noty/noty";
import { setToken } from "../sessionStorage/sessionStorage";
import { useEffectRedirectAuth } from "../useEffectRedirectAuth/useEffectRedirectAuth";

const Login = () => {
  // useEffectRedirectAuth();
  const OnLogin = async (e) => {
    e.preventDefault();
    const form = document.getElementById("form");
    const formData = new FormData(form);
    const formObj = {};
    for (const [key, value] of formData) {
      formObj[key] = value;
    }
    let token = await getLogin(formObj);
    
    if (!token) {
      return (window.location.href = "/login");
    }
    
    if (token.message === "Email and Password Not Match") {
      notification(token.message, "error");
      return;
    }
    notification(token.message);
    delete token.message;
    if (Object.keys(token).length === 0) {
      return;
    }
    setToken(token);

    setTimeout(() => {
      window.location.reload();
      window.location.href = "/";
    }, 5000);
  };

  return (
    <div>
      <div class="block mt-20 mx-auto p-6 rounded-lg shadow-lg bg-white max-w-md">
        <form onSubmit={OnLogin} id="form">
          <h3 class="font-bold text-xl mb-5"> Login Page</h3>

          <div class="form-group mb-6">
            <input
              type="email"
              name="email"
              class="form-control block
        w-full
        px-3
        py-1.5
        text-base
        font-normal
        text-gray-700
        bg-white bg-clip-padding
        border border-solid border-gray-300
        rounded
        transition
        ease-in-out
        m-0
        focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
              id="exampleInput125"
              placeholder="Email address"
            />
          </div>
          <div class="form-group mb-6">
            <input
              type="password"
              name="password"
              class="form-control block
        w-full
        px-3
        py-1.5
        text-base
        font-normal
        text-gray-700
        bg-white bg-clip-padding
        border border-solid border-gray-300
        rounded
        transition
        ease-in-out
        m-0
        focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
              id="exampleInput126"
              placeholder="Password"
            />
          </div>
          <div class="form-group form-check text-center mb-6">
            <input type="checkbox" class="m-3" />
            <label
              class="form-check-label inline-block text-gray-800"
              for="exampleCheck25"
            >
              Show Password
            </label>
          </div>
          <button
            type="submit"
            class="
      w-full
      px-6
      py-2.5
      bg-blue-600
      text-white
      font-medium
      text-xs
      leading-tight
      uppercase
      rounded
      shadow-md
      hover:bg-blue-700 hover:shadow-lg
      focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0
      active:bg-blue-800 active:shadow-lg
      transition
      duration-150
      ease-in-out"
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
