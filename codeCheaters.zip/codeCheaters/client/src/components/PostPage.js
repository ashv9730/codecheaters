import axios from "axios";
import React, { useEffect, useState } from "react";
import { staticUrl } from "../axios/axiosRequest";
import { useParams } from "react-router-dom";

const PostPage = () => {
  const [post, setPost] = useState(null);
  const { _id } = useParams();

  useEffect(() => {
    console.log(_id);

    axios.get(`${staticUrl}${_id}`).then((response) => {
      setPost(response.data);
      // console.log(post);
    });
  }, []);

  if (!post) return null;
  return (
    <div class="m-5">
      <h1>{post.title}</h1>
    </div>
  );
};

export default PostPage;
