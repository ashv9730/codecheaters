import React, { useState } from 'react'

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Blog from './Blog';
import Child from './Child';
import Footer from './Footer';
import Home from './Home';
import Login from './Login';
import Navbar from './Navbar';
import Parent from './Parent';
import Post from './Post';
import PostBlog from './PostBlog';
import PostPage from './PostPage';
import PrivateCoponent from './PrivateCoponent';
import Projects from './Projects';
import Reports from './Reports';
import Signup from './Signup';
import Team from './Team';

const Main = () => {
  
  return (
    <div>
      <BrowserRouter>
        <Navbar/>

        <Routes>
       
          <Route path="/" element={<Home/>} />
          <Route path="/post" element={<Post/>} />
          {/* <Route path="/parent" element={<Parent/>} />
          <Route path="/child" element={<Child/>} /> */}
          
          <Route path="/post/:_id" element={<PostPage/>}  /> 
          <Route path="/signup" element={<Signup/>} />
          <Route path="/login" element={<Login/>} />
          <Route element={<PrivateCoponent/>}>
          <Route path="/team" element={<Team/>} />
          <Route path="/projects" element={<Projects/>} />
          <Route path="/reports" element={<Reports/>} />
          <Route path="/blog" element={<Blog/>} />
          <Route path="/postblog" element={<PostBlog/>} />
          </Route>
        </Routes>
        <Footer/>
      </BrowserRouter>
        
    </div>
  )
}

export default Main