import React from 'react'

const Footer = () => {
  return (
    <div>
        <footer className="footer">
        <div className="footer-basic">
          <footer>
            <div className="social">
              <a href="https://www.instagram.com/">
                <i className="icon ion-social-instagram"></i>
              </a>
              <a href="https://www.instagram.com/">
                <i className="icon ion-social-snapchat"></i>
              </a>
              <a href="https://www.instagram.com/">
                <i className="icon ion-social-twitter"></i>
              </a>
              <a href="https://www.instagram.com/">
                <i className="icon ion-social-facebook"></i>
              </a>
            </div>
            <ul className="list-inline">
              <li className="list-inline-item">
                <a href="https://www.instagram.com/">Home</a>
              </li>
              <li className="list-inline-item">
                <a href="https://www.instagram.com/">Services</a>
              </li>
              <li className="list-inline-item">
                <a href="https://www.instagram.com/">About</a>
              </li>
              <li className="list-inline-item">
                <a href="https://www.instagram.com/">Terms</a>
              </li>
              <li className="list-inline-item">
                <a href="https://www.instagram.com/">Privacy Policy</a>
              </li>
            </ul>
            <p className="copyright">Company Name © 2018</p>
          </footer>
        </div>
      </footer>
    </div>
  )
}

export default Footer