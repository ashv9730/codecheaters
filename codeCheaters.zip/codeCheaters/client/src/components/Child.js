import React from 'react'

const Child = (props) => {
    return (
      <div>
        {props.message}
      </div>
    );
  };

export default Child