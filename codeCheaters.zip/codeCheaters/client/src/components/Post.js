import axios from "axios";
import React, { useEffect, useState } from "react";
import { getPost, staticUrl } from "../axios/axiosRequest";
import { Link } from "react-router-dom";


const Post = () => {
  const [post, setPost] = useState(null);

  useEffect(() => {
    axios.get(`${staticUrl}getpost`).then((response) => {
      setPost(response.data);
      console.log(post);
    });
  }, []);

  if (!post) return null;

  return (
    <>
      <div> Post</div>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 col-gap-12 row-gap-16">
        {post.map((element, key) => (
          <Link to={`/post/${element._id}`}>
            <div key={element._id} class="m-4 ">
              <div class="block  mx-auto p-6 rounded-lg shadow-lg bg-white ">
                <img src={`http://localhost:3100/uploads/${element.image}`} alt="blog image" class='w-1/4 h-1/4 ' />
                <h3>{element.title}</h3>
                <h3>{element.description}</h3>
                
              </div>
            </div>
          </Link>
        ))}
      </div>
    </>
  );
};

export default Post;
