import React from "react";
import { getSingup } from "../axios/axiosRequest";
import notification from "../noty/noty";
import { useEffectRedirectAuth } from "../useEffectRedirectAuth/useEffectRedirectAuth";

const Signup = () => {
  useEffectRedirectAuth();
  const onSingup = async (e) => {
    e.preventDefault();
    // console.log(firstName,lastName,contact,email,password)
    const form = document.getElementById("form");
    const formObj = {};
    const formData = new FormData(form);

    for (const [key, value] of formData) {
      formObj[key] = value;
    }
    // showing some error
    const res = await getSingup(formObj);
    if (res.message === "Email already Registered") {
      notification(res.message, "error");
      return;
    }
    if (res.message === "All Fields are required! Plz try again") {
      notification(res.message, "error");
      return;
    }
    notification(res.message);
    setTimeout(() => {
      window.location.href = "/login";
    }, 5000);
  };
  return (
    <div>
      <div class="block mt-20 mx-auto p-6 rounded-lg shadow-lg bg-white max-w-md">
        <form onSubmit={onSingup} id="form">
          <h3 class="font-bold text-xl mb-5"> SignUp Page</h3>
          <div class="flex">
            <div class="form-group mb-6 mr-4">
              <input
                type="text"
                name="firstName"
                // onChange={e => setFirstName(e.target.value)}
                class="form-control
          block
          w-full
          px-3
          py-1.5
          text-base
          font-normal
          text-gray-700
          bg-white bg-clip-padding
          border border-solid border-gray-300
          rounded
          transition
          ease-in-out
          m-0
          focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
                id="exampleInput123"
                aria-describedby="emailHelp123"
                placeholder="First name"
              />
            </div>
            <div class="form-group mb-6">
              <input
                type="text"
                name="lastName"
                // onChange={e => setLastName(e.target.value)}
                class="form-control
          block
          w-full
          px-3
          py-1.5
          text-base
          font-normal
          text-gray-700
          bg-white bg-clip-padding
          border border-solid border-gray-300
          rounded
          transition
          ease-in-out
          m-0
          focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
                id="exampleInput124"
                aria-describedby="emailHelp124"
                placeholder="Last name"
              />
            </div>
          </div>
          <div class="form-group mb-6">
            <input
              type="text"
              name="contact"
              // onChange={e => setContact(e.target.value)}
              class="form-control block
        w-full
        px-3
        py-1.5
        text-base
        font-normal
        text-gray-700
        bg-white bg-clip-padding
        border border-solid border-gray-300
        rounded
        transition
        ease-in-out
        m-0
        focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
              id="exampleInput125"
              placeholder="Contact no."
            />
          </div>
          <div class="form-group mb-6">
            <input
              type="email"
              name="email"
              // onChange={e => setEmail(e.target.value)}
              class="form-control block
        w-full
        px-3
        py-1.5
        text-base
        font-normal
        text-gray-700
        bg-white bg-clip-padding
        border border-solid border-gray-300
        rounded
        transition
        ease-in-out
        m-0
        focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
              id="exampleInput125"
              placeholder="Email address"
            />
          </div>
          <div class="form-group mb-6">
            <input
              type="password"
              name="password"
              // onChange={e => setPassword(e.target.value)}
              class="form-control block
        w-full
        px-3
        py-1.5
        text-base
        font-normal
        text-gray-700
        bg-white bg-clip-padding
        border border-solid border-gray-300
        rounded
        transition
        ease-in-out
        m-0
        focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
              id="exampleInput126"
              placeholder="Password"
            />
          </div>
          <div class="form-group form-check text-center mb-6">
            <input type="checkbox" class="m-3" />
            <label
              class="form-check-label inline-block text-gray-800"
              for="exampleCheck25"
            >
              Show Password
            </label>
          </div>
          <button
            type="submit"
            class="
      w-full
      px-6
      py-2.5
      bg-blue-600
      text-white
      font-medium
      text-xs
      leading-tight
      uppercase
      rounded
      shadow-md
      hover:bg-blue-700 hover:shadow-lg
      focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0
      active:bg-blue-800 active:shadow-lg
      transition
      duration-150
      ease-in-out"
          >
            Sign up
          </button>
        </form>
      </div>
    </div>
  );
};

export default Signup;
