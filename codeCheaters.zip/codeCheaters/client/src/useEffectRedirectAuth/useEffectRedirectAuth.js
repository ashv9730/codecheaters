import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Usertoken } from "../sessionStorage/sessionStorage";

export const useEffectRedirectAuth = () => {
  const navigate = useNavigate();

  useEffect(() => {
    if (Usertoken) {
      navigate("/");
    
    }
  });
  
};
