import Noty from "noty";
import "../../node_modules/noty/lib/noty.css";
import "../../node_modules/noty/lib/themes/mint.css";

export default function notification(message,type = 'success') {
  
    new Noty({
      type: type,
      text: message,
      progressBar: false,
      timeout: 2000,
    }).show();
  
}



