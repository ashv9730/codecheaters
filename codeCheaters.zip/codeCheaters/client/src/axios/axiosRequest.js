import axios from "axios";
export const staticUrl = `http://localhost:3100/api/`;
// signup
export const getSingup = async (payload) => {
  const res = await axios.post(`${staticUrl}singup`, payload);
  return res.data;
}

// login
export const getLogin = async (payload) => {
  const res = await axios.post(`${staticUrl}login`, payload);
  return res.data;
}
// post create
export const postCreate = async (payload) => {
  
  const res = await axios.post(`${staticUrl}postcreate`, payload)
  return res.data;
}
// getpost
export const getPost = async () => {
  
  const res = await axios.get(`${staticUrl}getpost`)
  return res.data;
}